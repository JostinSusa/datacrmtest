<?php 

define('APP_PATH', 'http://' . $_SERVER['HTTP_HOST'] . '/datacrm');

//definir controlador por defecto
define('DEFAULT_CONTROLLER', 'Index');

//definir función a ejecutar por defecto
define('DEFAULT_FUNCTION', 'Index');

//definir nombre de la aplicación
define('DEFAULT_APP_NAME', 'DataCRM');