<div class="container">
  <div class="row">
    <div class="col-12">
      <!-- Contenedor de la información -->
      <div class="info-container" id="infoContainer">
      </div>
    </div>
    <div class="col-12 d-flex justify-content-center">
      <!-- Botón que genera el llamado de información -->
      <span class="btn-show-info" id="btnShowInfo">Ver información</span>
    </div>
  </div>
</div>